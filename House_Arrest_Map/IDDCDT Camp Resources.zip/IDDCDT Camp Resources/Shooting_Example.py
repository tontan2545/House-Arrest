﻿import pygame       
import sys          
import os          

from pygame.locals import * 

pygame.init()

FPS = 60
fpsClock = pygame.time.Clock()

DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

# Level Information
levelData = [
            "BBBBBBBBBBBBBBBB",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "BBBBBBBBBBBBBBBB"
            ]

# Load Image
path = os.path.join("Sprites", "Back_Gradient_Day.png")
dayBG = pygame.image.load( path )
dayBG = pygame.transform.scale( dayBG, (1024, 767) )

path = os.path.join("Sprites", "BrownOnly_Middle_01.png")
blockSprite = pygame.image.load( path )
blockSprite = pygame.transform.scale( blockSprite, (64, 64) )

path = os.path.join("Sprites", "FlappyDuck.png")
duckSprite = pygame.image.load( path )
duckSprite = pygame.transform.scale( duckSprite, (64, 64) )
duckSprite = pygame.transform.flip( duckSprite , True , False )

path = os.path.join("Sprites", "Item_Bomb_01.png")
bulletSprite = pygame.image.load( path )
bulletSprite = pygame.transform.scale( bulletSprite, (16, 16) )

# Duck Attributes
duckPosX = 200
duckPosY = 352
duckDirectionX = 0
duckDirectionY = 0
onPressA = False
onPressD = False
onPressW = False
onPressS = False

# Level Rect Attributes
levelRect = []
###########################################################################
bulletList = []  # สร้าง List ของลูกกระสุนในฉาก เริ่มต้นมาไม่มีลูกกระสุนเลย
###########################################################################

while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )
    DISPLAYSURF.blit( dayBG, ( 0 , 0 ))

    # Reset Level Rect
    levelRect = []
    
    for row in range( 0 , 12 , 1 ) :
        for column in range( 0 , 16 , 1 ) :
            # Draw the game level
            if levelData[ row ][ column ] == "B" :
                DISPLAYSURF.blit( blockSprite, ( 64 * column , 64 * row ))
                # เพิ่ม Rect ของ Block แต่ละชิ้นลงไปใน levelRect ที่เป็น List เพื่อใช้ในการเช็คการชนต่อไป
                levelRect.append( pygame.Rect( 64 * column , 64 * row , 64 , 64 ) )

    duckDirectionX = 0
    duckDirectionY = 0
    # สร้าง Rect ของตัวละครเป็นเพื่อเช็คการชน
    duckRect = pygame.Rect( duckPosX , duckPosY , 64 , 64 )
    
    if onPressA == True :
        duckDirectionX += -5
    if onPressD == True :
        duckDirectionX += 5

    if onPressW == True :
        duckDirectionY += -5
    if onPressS == True :
        duckDirectionY += 5

    # ไล่ดู Rect ของ Block ที่เก็บไว้ใน levelRect ทุกชิ้น เพื่อดูว่า ตัวละครไปชนกับ Block ไหนหรือไม่
    for blockRect in levelRect :
        if duckRect.colliderect( blockRect ) :  # เจอแล้วว่าชนกับ Block นี้
            if blockRect.x < duckRect.x : # เช็คว่า Block นี้อยู่ตรงไหน ถ้าอยู่ซ้ายของตัวละคร ก็ให้ตัวละครเดินซ้ายไม่ได้
                if duckDirectionX < 0 :
                    duckDirectionX = 0
            elif blockRect.x > duckRect.x :  # เช็คว่า Block นี้อยู่ตรงไหน ถ้าอยู่ขวาของตัวละคร ก็ให้ตัวละครเดินขวาไม่ได้
                if duckDirectionX > 0 :
                    duckDirectionX = 0

            if blockRect.y > duckRect.y :  
                if duckDirectionY > 0 :
                    duckDirectionY = 0
            elif blockRect.y < duckRect.y :  
                if duckDirectionY < 0 :
                    duckDirectionY = 0

    duckPosX += duckDirectionX
    duckPosY += duckDirectionY          # ให้ตัวละครเคลื่อนที่ตามปุ่มที่เรากด

    DISPLAYSURF.blit( duckSprite, ( duckPosX , duckPosY ))

###########################################################################
    # วาดรูปลูกกระสุนที่ที่ใส่เข้าไปใน List จากการกดคลิกซ้ายในโคดด้านล่าง พร้อมสั่งเคลื่อนที่
    for bullet in bulletList :
        # วาดรูปลูกกระสุนตามตำแหน่งที่เก็บไว้
        DISPLAYSURF.blit( bulletSprite, ( bullet[0] , bullet[1] ))
        bullet[0] += 10   # เพิ่มตำแหน่งลูกกระสุนในแนวแกน X ไป 10 หน่วยทุกๆ Frame

        # ลบลูกกระสุนพร้อมยกเลิกการวาดลูกกระสุน เมื่อลูกกระสุนวิ่งออกไปนอกฉาก
        if bullet[0] > 1034 :
            bulletList.remove( bullet )

        # ตั้งค่า Bullet Rect เพื่อเช็คการชน
        bulletRect = pygame.Rect( bullet[0] , bullet[1] , 16 , 16 )

        # ถ้าชนกำแพงให้ลบลูกกระสุนและยกเลิกการวาด
        for blockRect in levelRect :
            if bulletRect.colliderect( blockRect ) :
                if bullet in bulletList :
                    bulletList.remove( bullet )
###########################################################################

    for event in pygame.event.get() :
        
        if event.type == QUIT :
            pygame.quit()       
            sys.exit()

        # เช็คการกดค้าง
        if event.type == KEYDOWN :
            if event.key == K_a :
                onPressA = True
            elif event.key == K_d :
                onPressD = True

            if event.key == K_w :
                onPressW = True
            elif event.key == K_s :
                onPressS = True

        if event.type == KEYUP :
            if event.key == K_a :
                onPressA = False
            elif event.key == K_d :
                onPressD = False

            if event.key == K_w :
                onPressW = False
            elif event.key == K_s :
                onPressS = False
###########################################################################
        elif event.type == MOUSEBUTTONDOWN and event.button == 1 :
            # สร้างและใส่ลูกกระสุนลงไปใน List พร้อมตั้งค่าตำแหน่งเริ่มต้นเป็น หน้าตัวละคร 60 หน่วย
            # และล่างจากจุดกึ่งกลางตัวละคร 20 หน่วย
            bulletList.append( [ duckPosX + 60 , duckPosY + 20 ] )
###########################################################################
                
    pygame.display.update()
    fpsClock.tick(FPS)




