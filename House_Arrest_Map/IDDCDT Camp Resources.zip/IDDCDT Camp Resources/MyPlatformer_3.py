﻿import pygame       
import sys          
import os          

from random import *
from pygame.locals import * 

pygame.init()

# Set Frame Per Second
FPS = 30
fpsClock = pygame.time.Clock()

DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

###############################################################################
# Level Information
levelData_1 = [
                "BBBBBBBBBBBBBBBB",
                "B   R SR RR   HB",
                "B R   RR    RRRB",
                "BCRSR    RR    B",
                "BRRRR RRRRS RRRB",
                "B R     RRR R SB",
                "B   RRR E R R RB",
                "B R RRR R   R RB",
                "B R     R R    B",
                "B RR RR R RRRRRB",
                "BP   RRSR     KB", 
                "BBBBBBBBBBBBBBBB"
            ]

levelData_2 = [
                "BBBBBBBBBBBBBBBB",
                "B   R  RSRR   KB",
                "B R   RR    RRRB",
                "BHR R    RR   SB",
                "BRRRR RRRRR RRRB",
                "B R     RRR R SB",
                "B E R R P R R RB",
                "B R R R R   R RB",
                "B R     R R    B",
                "B RR RR R RRRRRB",
                "BC   RRSR     SB", 
                "BBBBBBBBBBBBBBBB"
            ]

levelData = levelData_1

###############################################################################
# Load Image
path = os.path.join( "Sprites" , "Back_Gradient_Desert.png" )
dayBG = pygame.image.load( path )
dayBG = pygame.transform.scale( dayBG , (1024,768) )    # ขยายรูปให้กว้างสูง ( X , Y )

# Image -> B R C S H K P
path = os.path.join( "Sprites" , "BrownOnly_Middle_01.png" )
BImage = pygame.image.load( path )
BImage = pygame.transform.scale( BImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "StoneOnly_Middle_01.png" )
RImage = pygame.image.load( path )
RImage = pygame.transform.scale( RImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "Item_ChestClosed_01.png" )
CImage = pygame.image.load( path )
CImage = pygame.transform.scale( CImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "Item_RedStar_01.png" )
SImage = pygame.image.load( path )
SImage = pygame.transform.scale( SImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "House_01.png" )
HImage = pygame.image.load( path )
HImage = pygame.transform.scale( HImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "Item_Key_01.png" )
KImage = pygame.image.load( path )
KImage = pygame.transform.scale( KImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "FlappyDuck.png" )
PImage = pygame.image.load( path )
PImage = pygame.transform.scale( PImage , ( 64 , 64 ) )
PImage = pygame.transform.flip( PImage , True , False ) # Flip แค่ X ไม่ Flip Y

path = os.path.join( "Sprites" , "Alien.png" )
EImage = pygame.image.load( path )
EImage = pygame.transform.scale( EImage , ( 64 , 64 ) )

path = os.path.join( "Sprites" , "FlappyDuck 01.png" )
P01Image = pygame.image.load( path )
P01Image = pygame.transform.scale( P01Image , ( 64 , 64 ) )
P01Image = pygame.transform.flip( P01Image , True , False )

path = os.path.join( "Sprites" , "FlappyDuck 02.png" )
P02Image = pygame.image.load( path )
P02Image = pygame.transform.scale( P02Image , ( 64 , 64 ) )
P02Image = pygame.transform.flip( P02Image , True , False )

duckFlyingSequence = []
duckFlyingSequence.append(P01Image)
duckFlyingSequence.append(P02Image)
currentAnimationFrame = 0

###############################################################################
# Load Font
fontObj = pygame.font.Font( "Kanit-Medium.ttf" , 32 )   # Font name and size

###############################################################################
# Gameplay Information
playerAtRow = 0
playerAtColumn = 0
enemyAtRow = 0
enemyAtColumn = 0
facingRight = True

itemDictionary = {}   # สร้าง Dictionary ขึ้นมาเพื่อเก็บ Rect ของ Item แต่ละชิ้น
playerScore = 0
removeItem = []
keyCollected = 0
isGameEnd = False
gotoNextLevel = False

enemyMovementCounter = 0
enemyMoveSpeed = 15
duckAnimationCounter = 0

###############################################################################
while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )       # เหมือนเป็นการ Clear หน้าจอ

    # วาดพื้นหลัง
    DISPLAYSURF.blit( dayBG , ( 0 , 0 ) )

    ###############################################################################
    # วาดวัตถุในฉาก Image -> B R C S H K P
    for row in range( 0 , 12 , 1 ) : # 0 1 2 3 4 5 6 .... 12
        for column in range( 0 , 16 , 1 ) : # 0 1 2 3 4 5 ... 16
            if levelData[row][column] == "B" : # ความกว้างของวัตถุคูณ Column กับ Row
                DISPLAYSURF.blit( BImage , ( 64 * column , 64 * row ) )
                
            elif levelData[row][column] == "R" :
                DISPLAYSURF.blit( RImage , ( 64 * column , 64 * row ) )
                
            elif levelData[row][column] == "C" :
                itemName = "C_" + str(column) + "_" + str(row)
                if ( itemName in removeItem ) == False :
                    DISPLAYSURF.blit( CImage , ( 64 * column , 64 * row ) )
                    # เพิ่ม Key เข้าไปใน Dictionary เป็น Rect ของ item
                    if ( itemName in itemDictionary ) == False : # ถ้ามีแล้วก็ไม่ต้องเพิ่ม
                        itemDictionary[ itemName ] = pygame.Rect( 64 * column ,
                                                                  64 * row ,
                                                                  64 , 64 )
                
            elif levelData[row][column] == "S" :
                itemName = "S_" + str(column) + "_" + str(row)
                # ถ้า Item ชื่อนี้อยู่ใน RemoveItem List ก็จะไม่วาดมันอีก
                if ( itemName in removeItem ) == False :
                    DISPLAYSURF.blit( SImage , ( 64 * column , 64 * row ) )
                    # เพิ่ม Key เข้าไปใน Dictionary เป็น Rect ของ item
                    if ( itemName in itemDictionary ) == False : # ถ้ามีแล้วก็ไม่ต้องเพิ่ม
                        itemDictionary[ itemName ] = pygame.Rect( 64 * column ,
                                                                  64 * row ,
                                                                  64 , 64 )
                
            elif levelData[row][column] == "H" :
                DISPLAYSURF.blit( HImage , ( 64 * column , 64 * row ) )
                itemName = "H_" + str(column) + "_" + str(row)
                # เพิ่ม Key เข้าไปใน Dictionary เป็น Rect ของ item
                if ( itemName in itemDictionary ) == False : # ถ้ามีแล้วก็ไม่ต้องเพิ่ม
                    itemDictionary[ itemName ] = pygame.Rect( 64 * column ,
                                                              64 * row ,
                                                              64 , 64 )
                
            elif levelData[row][column] == "K" :
                itemName = "K_" + str(column) + "_" + str(row)
                if ( itemName in removeItem ) == False :
                    DISPLAYSURF.blit( KImage , ( 64 * column , 64 * row ) )
                    # เพิ่ม Key เข้าไปใน Dictionary เป็น Rect ของ item
                    if ( itemName in itemDictionary ) == False : # ถ้ามีแล้วก็ไม่ต้องเพิ่ม
                        itemDictionary[ itemName ] = pygame.Rect( 64 * column ,
                                                                  64 * row ,
                                                                  64 , 64 )
                
            elif levelData[row][column] == "P" :
                if playerAtRow == 0 and playerAtColumn == 0 :    # ตั้งค่าตำแหน่งเริ่มต้น
                    playerAtRow = row           # ตั้งค่า Row เริ่มต้น
                    playerAtColumn = column     # ตั้งค่า Column เริ่มต้น
            elif levelData[row][column] == "E" :
                if enemyAtRow == 0 and enemyAtColumn == 0 :    # ตั้งค่าตำแหน่งเริ่มต้น
                    enemyAtRow = row           # ตั้งค่า Row เริ่มต้น
                    enemyAtColumn = column     # ตั้งค่า Column เริ่มต้น

    ###############################################################################
    # Duck Animation
    duckAnimationCounter += 1

    if duckAnimationCounter == 5 :
        duckAnimationCounter = 0
        currentAnimationFrame += 1
        if currentAnimationFrame > 1 :
            currentAnimationFrame = 0

    ###############################################################################
    # Rect( X Position , Y Position , Width , Height )
    # ตั้งแค่อาณาเขตที่สามารถไปชนกับ Rect หรืออาณาเขตอื่นๆได้
    playerRect = pygame.Rect( 64 * playerAtColumn , 64 * playerAtRow , 64 , 64 )
    enemyRect = pygame.Rect( 64 * enemyAtColumn , 64 * enemyAtRow , 64 , 64 )

    DISPLAYSURF.blit( duckFlyingSequence[ currentAnimationFrame ] , ( 64 * playerAtColumn , 64 * playerAtRow ) )
    DISPLAYSURF.blit( EImage , ( 64 * enemyAtColumn , 64 * enemyAtRow ) )

    ###############################################################################
    # เช็คว่า Player กับ Enemy ชนกันหรือเปล่า
    if playerRect.colliderect( enemyRect ) :
        if isGameEnd == False :         # ถ้าเกมยังไม่จบ
            print( "Game Over !!!" )
            print( "Player has : " + str( playerScore ) )
            isGameEnd = True            # ตั้งค่าว่าจบแล้ว เพราะชน Alien

    # เช็คว่า Player ของเรา เดินไปชน Item อะไรหรือเปล่า
    # ไล่เช็คว่า Item แต่ละชิ้น ชนกับ Player ไหม
    for itemKey in itemDictionary :
        # ถ้า Item ชื่อนี้ไม่ได้อยู่ใน RemoveItem List ก็เช็คการชนกันกับ Player ปกติ
        if (itemKey in removeItem) == False :
            if playerRect.colliderect( itemDictionary[ itemKey ] ) :
                
                if itemKey[0] == "S" :  # "S_10_3" => itemKey[0] = "S" เช็คเมื่อชนกับ S
                    playerScore += 1
                    print( "Player has : " + str( playerScore ) )
                    removeItem.append( itemKey ) # เก็บตัวที่ถูกเป็ดชนไปแล้ว เพื่อที่จะได้ไม่ได้วาดอีกแล้ว

                if itemKey[0] == "C" :  # เช็คว่าชนกับกล่องสมบัติไหม
                    if keyCollected > 0 :   # เช็คก่อนว่ามีกุญแจไหม
                        playerScore += 10
                        print( "Player has : " + str( playerScore ) )
                        removeItem.append( itemKey )
                        keyCollected += -1  # ลดกุญแจเมื่อเก็บกล่อง

                if itemKey[0] == "K" :  # เช็คว่าชนกับกุญแจไหม
                    keyCollected += 1   # เพิ่มจำนวนกุญแจ เมื่อเก็บกุญแจได้
                    removeItem.append( itemKey )

                if itemKey[0] == "H" :  # เช็คว่าชนกับบ้านไหม
                    print( "Player reach the house." )
                    print( "Player has : " + str( playerScore ) )
                    removeItem.append( itemKey )
                    gotoNextLevel = True
                    isGameEnd = True

    # การเดินแบบสุ่มของ Alien
    enemyMovementCounter += 1   # Count Frame if frame is equal to 15 then ... move.

    if enemyMovementCounter == enemyMoveSpeed and isGameEnd == False :
        enemyMovementCounter = 0
        directionList = [ "LEFT" , "RIGHT" , "UP" , "DOWN" ]

        if levelData[enemyAtRow][enemyAtColumn-1] == "B" or levelData[enemyAtRow][enemyAtColumn-1] == "R" :
            directionList.remove( "LEFT" )
        if levelData[enemyAtRow][enemyAtColumn+1] == "B" or levelData[enemyAtRow][enemyAtColumn+1] == "R" :
            directionList.remove( "RIGHT" )
        if levelData[enemyAtRow-1][enemyAtColumn] == "B" or levelData[enemyAtRow-1][enemyAtColumn] == "R" :
            directionList.remove( "UP" )
        if levelData[enemyAtRow+1][enemyAtColumn] == "B" or levelData[enemyAtRow+1][enemyAtColumn] == "R" :
            directionList.remove( "DOWN" )

        number = randint( 0 , len(directionList) - 1 ) # len() ใข้หาขนาดของ List
        # -1 เพราะว่า ถ้ามี 4 ทิศ มันจะใช้ได้แค่ 0 1 2 3 เพราะมันเริ่มที่ 0
    
        if directionList[ number ] == "LEFT" :
            enemyAtColumn += -1
        elif directionList[ number ] == "RIGHT" :
            enemyAtColumn += 1
        elif directionList[ number ] == "UP" :
            enemyAtRow += -1
        elif directionList[ number ] == "DOWN" :
            enemyAtRow += 1

    ###############################################################################
    # วาด User Interface
    # render( Sentence , Visible , Font Color , Background Color )
    # ไม่ต้องใส่ Background ถ้าต้องการให้พื้นหลังใส
    textSurface = fontObj.render( "Score : " + str(playerScore) , True , WHITE )
    textRect = textSurface.get_rect()
    textRect.center = ( 100 , 30 )      # ว่างที่ ( X , Y )
    DISPLAYSURF.blit( textSurface , textRect  )

    if isGameEnd == True :
        restartButton = pygame.draw.rect( DISPLAYSURF , WHITE , ( 387 , 500 , 250 , 50 ) )
        restartSurface = fontObj.render( "Restart Level" , True , BLACK )
        restartRect = restartSurface.get_rect()
        restartRect.center = (513,523)
        DISPLAYSURF.blit( restartSurface , restartRect  )

    if gotoNextLevel == True :
        nextLevelButton = pygame.draw.rect( DISPLAYSURF , WHITE , ( 387 , 420 , 250 , 50 ) )
        nextLevelSurface = fontObj.render( "Next Level" , True , BLACK )
        nextLevelRect = nextLevelSurface.get_rect()
        nextLevelRect.center = (513,443)
        DISPLAYSURF.blit( nextLevelSurface , nextLevelRect  )

    ###############################################################################
    # เช็ค Event ต่างๆที่เกิดขึ้นภายในเกม
    for event in pygame.event.get() :
        if event.type == QUIT :
            pygame.quit()       
            sys.exit()

        # เช็คการกดปุ่มบน Mouse
        elif event.type == MOUSEBUTTONDOWN :
            if event.button == 1 :      # 1 Left , 2 Right 3 Middle Mouse Button
                mousePos = pygame.mouse.get_pos()
                if restartButton.collidepoint( mousePos ) == True : # Check mouse click on UI
                    # เพื่อเริ่มเกมใหม่ ให้ตั้งค่าทุกค่าที่เราใช้ กลับมาเป็นค่าตั้งต้น
                    playerAtRow = 0
                    playerAtColumn = 0
                    enemyAtRow = 0
                    enemyAtColumn = 0
                    if facingRight == False :
                        facingRight = True
                        for index in range( 0 , len(duckFlyingSequence) , 1 ):
                            duckFlyingSequence[ index ] = pygame.transform.flip( duckFlyingSequence[ index ] , True , False )
                    playerRect = 0
                    enemyRect = 0
                    itemDictionary = {}
                    removeItem = []
                    keyCollected = 0
                    playerScore = 0
                    enemyMovementCounter = 0
                    isGameEnd = False
                    gotoNextLevel = False
                    
                if nextLevelButton.collidepoint( mousePos ) :
                    playerAtRow = 0
                    playerAtColumn = 0
                    enemyAtRow = 0
                    enemyAtColumn = 0
                    if facingRight == False :
                        facingRight = True
                        for index in range( 0 , len(duckFlyingSequence) , 1 ):
                            duckFlyingSequence[ index ] = pygame.transform.flip( duckFlyingSequence[ index ] , True , False )
                    playerRect = 0
                    enemyRect = 0
                    itemDictionary = {}
                    removeItem = []
                    keyCollected = 0
                    enemyMovementCounter = 0
                    isGameEnd = False
                    gotoNextLevel = False
                    enemyMoveSpeed = int( enemyMoveSpeed * 0.8 )
                    if levelData == levelData_1 :   # Repeat วนเล่น Level 1 กับ 2 ไปเรื่อยๆ
                        levelData = levelData_2
                    elif levelData == levelData_2 :
                        levelData = levelData_1
                
        elif event.type == KEYDOWN and isGameEnd == False :    # Change Row and Column ของตัวละครเมื่อกดปุ่ม
            
            if event.key == K_w or event.key == K_UP : # เช็คก่อนว่าตำแหน่งที่จะไป ไม่ใช่ B และ R
                if levelData[playerAtRow-1][playerAtColumn] != "B" :
                    if levelData[playerAtRow-1][playerAtColumn] != "R" : 
                        playerAtRow += -1
                        
            elif event.key == K_s or event.key == K_DOWN :
                if levelData[playerAtRow+1][playerAtColumn] != "B" :
                    if levelData[playerAtRow+1][playerAtColumn] != "R" :
                        playerAtRow += 1
                        
            elif event.key == K_a or event.key == K_LEFT :
                if levelData[playerAtRow][playerAtColumn-1] != "B" :
                    if levelData[playerAtRow][playerAtColumn-1] != "R" :
                        playerAtColumn += -1
                        if facingRight == True : # ถ้าหันขวาอยู่ ให้ Flip
                            for index in range( 0 , len(duckFlyingSequence) , 1 ):
                                duckFlyingSequence[ index ] = pygame.transform.flip( duckFlyingSequence[ index ] , True , False )
                            facingRight = False  # ตั้งค่าว่าไม่ได้หันขวาแล้ว
                        
            elif event.key == K_d or event.key == K_RIGHT :
                if levelData[playerAtRow][playerAtColumn+1] != "B" :
                    if levelData[playerAtRow][playerAtColumn+1] != "R" :
                        playerAtColumn += 1
                        if facingRight == False : # ถ้าไม่ได้หันขวาอยู่ ให้ Flip
                            for index in range( 0 , len(duckFlyingSequence) , 1 ):
                                duckFlyingSequence[ index ] = pygame.transform.flip( duckFlyingSequence[ index ] , True , False )
                            facingRight = True   # ตั้งค่าว่ากลับมาหันขวาแล้ว

    pygame.display.update()
    fpsClock.tick(FPS)






