import pygame       # ดึงคำสั่งที่เราต้องการมาใช้ในที่นี้คือ PyGame.
import sys          # ดึงข้อมูลของคอมพิวเตอร์ที่เราใช้ขณะนั้นมาใช้.
import os           # เพื่อให้เราสามารถดึงไฟล์หรือรูปจาก Folder อื่นได้

from pygame.locals import * # Use Pygame Setting.

pygame.init()  # เปิด PyGame.
# ใช้เลขฐาน 2 เพราะมันประหยัดกว่า
DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
# ตั้งซื้อของหน้าต่าง
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

# Load Image เพื่อนำมาวาดใน PyGame
path = os.path.join( "Sprites" , "FlappyDuck.png" ) # สร้างตำแหน่ง Folder ของรูป
PImage = pygame.image.load( path )  # โหลดรูปเข้ามาใน PyGame
PImage = pygame.transform.scale( PImage , ( 64 , 64 ) ) # Set size.

duckPosX = 128
duckPosY = 128

while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )
    # ( 0 , 0 ) อยู่ซ้ายบน
    # pygame.draw.polygon(DISPLAYSURF,GREEN,((200,200),(300,100),(100,100)))
    # Rect ใช้ในการวาดรูปสี่เหลี่ยม ใช้บ่อยในการวาดปุ่ม
    # pygame.draw.rect(DISPLAYSURF,RED,(100,100,300,300))

    # วาดรูปเป็ดที่โหลดเข้ามาจากด้านบน   โหลด 1 ที วาดกี่ครั้งก็ได้
    DISPLAYSURF.blit( PImage , ( duckPosX , duckPosY ) )
    # DISPLAYSURF.blit( PImage , ( 512 , 512 ) )
    # DISPLAYSURF.blit( PImage , ( 256 , 256 ) )
    
    # เช็คว่ามีเหตุการณ์อะไรเกิดขึ้นบ้าง
    for event in pygame.event.get() :
        # ถ้า Event ที่เกิดขึ้นเป็น ...
        if event.type == QUIT :
            pygame.quit()       # ออกจาก PyGame
            sys.exit()          # ปิดหน้าต่าง
        elif event.type == KEYDOWN :    # เช็คว่ากดปุ่มอะไรไหม ณ ตอนนี้
            if event.key == K_w or event.key == K_UP :
                if duckPosY - 64 >= 0 :     # ถ้าเดินไปแล้ว ตำแหน่งไม่น้อยกว่า 0 (ไม่หลุดจอ)
                    duckPosY += -64         # ให้เป็ดเดินไป
            elif event.key == K_s or event.key == K_DOWN :
                if duckPosY + 64 < 768 :    # ถ้าเดินไปแล้ว ตำแหน่งไม่มากกว่า 768 (ไม่หลุดจอ)
                    duckPosY += 64
            elif event.key == K_a or event.key == K_LEFT :
                if duckPosX - 64 >= 0 :     # ถ้าเดินไปแล้ว ตำแหน่งไม่น้อยกว่า 0 (ไม่หลุดจอ)
                    duckPosX += -64
            elif event.key == K_d or event.key == K_RIGHT :
                if duckPosX + 64 < 1024 :   # ถ้าเดินไปแล้ว ตำแหน่งไม่มากกว่า 1024 (ไม่หลุดจอ)
                    duckPosX += 64

    pygame.display.update()     # เพื่อให้หน้าจอเปลี่ยนแปลงตามที่เราต้องการ




    
    
