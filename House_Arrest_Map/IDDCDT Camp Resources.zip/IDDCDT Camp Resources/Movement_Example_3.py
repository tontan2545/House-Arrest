﻿import pygame       
import sys          
import os          

from pygame.locals import * 

pygame.init()

FPS = 60
fpsClock = pygame.time.Clock()

DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

# Level Information
levelData = [
            "BBBBBBBBBBBBBBBB",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "B              B",
            "BBBBBBBBBBBBBBBB"
            ]

# Load Image
path = os.path.join("Sprites", "Back_Gradient_Day.png")
dayBG = pygame.image.load( path )
dayBG = pygame.transform.scale( dayBG, (1024, 767) )

path = os.path.join("Sprites", "BrownOnly_Middle_01.png")
blockSprite = pygame.image.load( path )
blockSprite = pygame.transform.scale( blockSprite, (64, 64) )

path = os.path.join("Sprites", "FlappyDuck.png")
duckSprite = pygame.image.load( path )
duckSprite = pygame.transform.scale( duckSprite, (64, 64) )
duckSprite = pygame.transform.flip( duckSprite , True , False )

# Duck Attributes
duckPosX = 200
duckPosY = 352
duckDirectionX = 0
duckDirectionY = 0
onPressA = False
onPressD = False
onPressW = False
onPressS = False

# Level Rect Attributes
levelRect = []

while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )
    DISPLAYSURF.blit( dayBG, ( 0 , 0 ))

    # Reset Level Rect
    levelRect = []
    
    for row in range( 0 , 12 , 1 ) :
        for column in range( 0 , 16 , 1 ) :
            # Draw the game level
            if levelData[ row ][ column ] == "B" :
                DISPLAYSURF.blit( blockSprite, ( 64 * column , 64 * row ))
                # เพิ่ม Rect ของ Block แต่ละชิ้นลงไปใน levelRect ที่เป็น List เพื่อใช้ในการเช็คการชนต่อไป
                levelRect.append( pygame.Rect( 64 * column , 64 * row , 64 , 64 ) )

    duckDirectionX = 0
    duckDirectionY = 0
    ############################################################################
    # สร้าง Rect ของตัวละครเป็นเพื่อเช็คการชน
    # อัพเดตเป็น มี Rect 4 ด้าน บน ล่าง ซ้าย ขวา Rect ด้านไหนชน ด้านนั้นจะเดินไม่ได้
    duckRectLeft = pygame.Rect( duckPosX , duckPosY + 24 , 10 , 16 )
    duckRectRight = pygame.Rect( duckPosX + 54 , duckPosY + 24 , 10 , 16 )
    duckRectUp = pygame.Rect( duckPosX + 24 , duckPosY , 16 , 10 )
    duckRectDown = pygame.Rect( duckPosX + 24 , duckPosY + 54 , 16 , 10 )
    ############################################################################
    
    if onPressA == True :
        duckDirectionX += -16
    if onPressD == True :
        duckDirectionX += 16

    if onPressW == True :
        duckDirectionY += -16
    if onPressS == True :
        duckDirectionY += 16

    ############################################################################
    # ไล่ดู Rect ของ Block ที่เก็บไว้ใน levelRect ทุกชิ้น เพื่อดูว่า ตัวละครไปชนกับ Block ไหนหรือไม่
    for blockRect in levelRect :
        if duckRectLeft.colliderect(blockRect) :
            if duckDirectionX < 0 : 
                duckDirectionX = 0
            #print("Hit Left")
        if duckRectRight.colliderect(blockRect) :
            if duckDirectionX > 0 :
                duckDirectionX = 0
            #print("Hit Right")
        if duckRectUp.colliderect(blockRect) :
            if duckDirectionY < 0 :
                duckDirectionY = 0
            #print("Hit Up")
        if duckRectDown.colliderect(blockRect) :
            if duckDirectionY > 0 :
                duckDirectionY = 0
            #print("Hit Down")

    #print(str(duckDirectionX) + "," + str(duckDirectionY))
    ############################################################################
        
    duckPosX += duckDirectionX
    duckPosY += duckDirectionY          # ให้ตัวละครเคลื่อนที่ตามปุ่มที่เรากด

    DISPLAYSURF.blit( duckSprite, ( duckPosX , duckPosY ))

    for event in pygame.event.get() :
        
        if event.type == QUIT :
            pygame.quit()       
            sys.exit()

        # เช็คการกดค้าง
        if event.type == KEYDOWN :
            if event.key == K_a :
                onPressA = True
            elif event.key == K_d :
                onPressD = True

            if event.key == K_w :
                onPressW = True
            elif event.key == K_s :
                onPressS = True


        if event.type == KEYUP :
            if event.key == K_a :
                onPressA = False
            elif event.key == K_d :
                onPressD = False

            if event.key == K_w :
                onPressW = False
            elif event.key == K_s :
                onPressS = False
                
    pygame.display.update()
    fpsClock.tick(FPS)




