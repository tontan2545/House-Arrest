﻿import pygame       
import sys          
import os          

from pygame.locals import * 

pygame.init()

FPS = 60
fpsClock = pygame.time.Clock()

DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

# Load Image
path = os.path.join("Sprites", "Back_Gradient_Day.png")
dayBG = pygame.image.load( path )
dayBG = pygame.transform.scale( dayBG, (1024, 767) )

path = os.path.join("Sprites", "FlappyDuck.png")
duckSprite = pygame.image.load( path )
duckSprite = pygame.transform.scale( duckSprite, (64, 64) )
duckSprite = pygame.transform.flip( duckSprite , True , False )

duckPosX = 200
duckPosY = 352

duckDirectionX = 0
duckDirectionY = 0

while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )
    DISPLAYSURF.blit( dayBG, ( 0 , 0 ))

    duckPosX += duckDirectionX
    duckPosY += duckDirectionY          # ให้ตัวละครเคลื่อนที่ตามปุ่มที่เรากด

    DISPLAYSURF.blit( duckSprite, ( duckPosX , duckPosY ))

    for event in pygame.event.get() :
        
        if event.type == QUIT :
            pygame.quit()       
            sys.exit()

        elif event.type == KEYDOWN :    # ถ้ากดปุ่มไปแล้ว ยังไม่ปล่อย(UP) ก็แสดงว่ากดค้าง
            if event.key == K_w : 
                duckDirectionY = -3     # ถ้ากดแล้วให้ตัวละครเคลื่อนที่ไปทีละ 3 หน่วย
            elif event.key == K_s :
                duckDirectionY = 3

            if event.key == K_a :
                duckDirectionX = -3
            elif event.key == K_d :
                duckDirectionX = 3

        elif event.type == KEYUP :      # ถ้าปล่อยปุ่มก็คือสิ้นสุดการกดค้างแล้ว
            if event.key == K_w :
                duckDirectionY = 0      # เมื่อปล่อยปุ่มให้ตัวละครเคลื่อนที่ไปทีละ 0 หน่วย (ไม่เคลื่อนที่)
            elif event.key == K_s :
                duckDirectionY = 0

            if event.key == K_a :
                duckDirectionX = 0
            elif event.key == K_d :
                duckDirectionX = 0

    pygame.display.update()
    fpsClock.tick(FPS)




