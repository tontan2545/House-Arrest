﻿import pygame       
import sys          
import os          

from pygame.locals import * 

pygame.init()

FPS = 60
fpsClock = pygame.time.Clock()

DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

# Level Information
levelData = [
            "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "B                                         B",
            "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"
            ]

# Load Image
path = os.path.join("Sprites", "Back_Gradient_Day.png")
dayBG = pygame.image.load( path )
dayBG = pygame.transform.scale( dayBG, (1024, 767) )

path = os.path.join("Sprites", "BrownOnly_Middle_01.png")
blockSprite = pygame.image.load( path )
blockSprite = pygame.transform.scale( blockSprite, (64, 64) )

path = os.path.join("Sprites", "FlappyDuck.png")
duckSprite = pygame.image.load( path )
duckSprite = pygame.transform.scale( duckSprite, (64, 64) )
duckSprite = pygame.transform.flip( duckSprite , True , False )

# Duck Attributes
duckPosX = 200
duckPosY = 352
duckDirectionX = 0
duckDirectionY = 0
onPressA = False
onPressD = False
onPressW = False
onPressS = False
facingRight = True

# Level Rect Attributes
levelRect = []
levelOffset = 0 # ค่า Offset สำหรับการเลื่อนฉาก

while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )
    DISPLAYSURF.blit( dayBG, ( 0 , 0 ))

    # Reset Level Rect
    levelRect = []

#############################################################################
    # เพื่อค่า Offset เข้าไปเพื่อเลื่อนฉาก
    # ขยายช่วงการวน Loop ตามขนาดของฉาก
    for row in range( 0 , len( levelData ) , 1 ) :
        for column in range( 0 , len( levelData[row] ) , 1 ) :
            # Draw the game level
            if levelData[ row ][ column ] == "B" :
                DISPLAYSURF.blit( blockSprite, ( 64 * column - levelOffset , 64 * row ))
                # เพิ่ม Rect ของ Block แต่ละชิ้นลงไปใน levelRect ที่เป็น List เพื่อใช้ในการเช็คการชนต่อไป
                levelRect.append( pygame.Rect( 64 * column - levelOffset , 64 * row , 64 , 64 ) )
############################################################################# 

    duckDirectionX = 0
    duckDirectionY = 0
    # สร้าง Rect ของตัวละครเป็นเพื่อเช็คการชน
    duckRect = pygame.Rect( duckPosX , duckPosY , 64 , 64 )
    
    if onPressA == True :
        duckDirectionX += -5
    if onPressD == True :
        duckDirectionX += 5

    if onPressW == True :
        duckDirectionY += -5
    if onPressS == True :
        duckDirectionY += 5

    # ไล่ดู Rect ของ Block ที่เก็บไว้ใน levelRect ทุกชิ้น เพื่อดูว่า ตัวละครไปชนกับ Block ไหนหรือไม่
    for blockRect in levelRect :
        if duckRect.colliderect( blockRect ) :  # เจอแล้วว่าชนกับ Block นี้
            if blockRect.x < duckRect.x : # เช็คว่า Block นี้อยู่ตรงไหน ถ้าอยู่ซ้ายของตัวละคร ก็ให้ตัวละครเดินซ้ายไม่ได้
                if duckDirectionX < 0 :
                    duckDirectionX = 0
            elif blockRect.x > duckRect.x :  # เช็คว่า Block นี้อยู่ตรงไหน ถ้าอยู่ขวาของตัวละคร ก็ให้ตัวละครเดินขวาไม่ได้
                if duckDirectionX > 0 :
                    duckDirectionX = 0

            if blockRect.y > duckRect.y :  
                if duckDirectionY > 0 :
                    duckDirectionY = 0
            elif blockRect.y < duckRect.y :  
                if duckDirectionY < 0 :
                    duckDirectionY = 0

#############################################################################
    # ถ้าตัวละครเคลื่อนที่ไปเกินค่า X เท่านี้ให้เลื่อนฉากแทนตัวละคร เพื่อขยับฉาก
    # แล้วเอาค่าที่เกินมา มาใส่เป็น Offset แทน
    if duckDirectionX > 0 :                 # ถ้าเดินไปทางขวา
        if levelOffset + duckDirectionX < 1730 :   # ค่า Offset มากที่สุดที่อยากให้เป็นได้คือ 1730 เพื่อไม่ให้ฉากเลื่อนตอนไปสุดแล้ว
            if duckPosX + duckDirectionX > 500 :
                duckPosX = 500                  # Set ไม่ให้ตัวละครไปไกลเกินกลางหน้าจอ
                levelOffset += duckDirectionX   # เพิ่มค่า Offset ให้ฉากเลื่อนแทนตัวละคร
                if levelOffset < 0 :            # ถ้ามันค่าลดลงไปน้อยกว่า 0 ให้ตั้งค่าเป็น 0
                    levelOffset = 0
            else :
                duckPosX += duckDirectionX
        else :
            levelOffset = 1730              # ตั้งค่า Offset เป็นค่ามากที่สุดแทน ถ้าเกิน
            duckPosX += duckDirectionX      # ให้ตัวละครเดินต่อเมื่อถึงขอบขวาฉากแล้ว

    elif duckDirectionX < 0 :               # ถ้าเดินไปทางซ้าย
        if duckPosX + duckDirectionX <= 500 :    # ถ้าตัวละครอยู่ที่ขวาสุดฉาก ให้เดินกลับมาที่ 500 ก่อน
            if levelOffset > 0 :                # ถ้าค่า Offset มากกว่า 0 ให้ทดค่า Offset กลับมาเรื่อยๆจนเป็น 0 ก่อน
                levelOffset += duckDirectionX  
                if levelOffset < 0 :            # ถ้ามันค่าลดลงไปน้อยกว่า 0 ให้ตั้งค่าเป็น 0
                    levelOffset = 0
            else :
                duckPosX += duckDirectionX
        else :
            duckPosX += duckDirectionX          # ให้เดินกลับมาที่ 500 ก่อนเลื่อนฉากกลับ
            if duckPosX < 500 :
                duckPosX = 500
            
    duckPosY += duckDirectionY          # ให้ตัวละครเคลื่อนที่ตามปุ่มที่เรากดตามแนว Y
            
#############################################################################

    DISPLAYSURF.blit( duckSprite, ( duckPosX , duckPosY ))

    for event in pygame.event.get() :
        
        if event.type == QUIT :
            pygame.quit()       
            sys.exit()

        # เช็คการกดค้าง
        if event.type == KEYDOWN :
            if event.key == K_a :
                onPressA = True
                if facingRight == True :
                    duckSprite = pygame.transform.flip( duckSprite , True , False )
                    facingRight = False
            elif event.key == K_d :
                onPressD = True
                if facingRight == False :
                    duckSprite = pygame.transform.flip( duckSprite , True , False )
                    facingRight = True

            if event.key == K_w :
                onPressW = True
            elif event.key == K_s :
                onPressS = True

        if event.type == KEYUP :
            if event.key == K_a :
                onPressA = False
            elif event.key == K_d :
                onPressD = False

            if event.key == K_w :
                onPressW = False
            elif event.key == K_s :
                onPressS = False
                
    pygame.display.update()
    fpsClock.tick(FPS)




