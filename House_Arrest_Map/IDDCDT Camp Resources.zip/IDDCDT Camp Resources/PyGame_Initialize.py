import pygame       
import sys          
import os          

from pygame.locals import * 

pygame.init() 
DISPLAYSURF = pygame.display.set_mode( ( 1024 , 768 ) )
pygame.display.set_caption( "My Game" )

# Setup Color Pattern
WHITE = ( 255 , 255 , 255 )
BLACK = ( 0 , 0 , 0 )
RED = ( 255 , 0 , 0 )
GREEN = ( 0 , 255 , 0 )
BLUE = ( 0 , 0 , 255 )

while True :        # Game Loop run forever.

    DISPLAYSURF.fill( WHITE )

    for event in pygame.event.get() :
        if event.type == QUIT :
            pygame.quit()       
            sys.exit()          

    pygame.display.update()


    
